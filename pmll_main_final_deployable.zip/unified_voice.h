
#ifndef UNIFIED_VOICE_H
#define UNIFIED_VOICE_H

#include "io_socket.h"
#include "pml_logic_loop.h"

// Define Graph and Node as placeholders
typedef struct Graph {
    int node_count;
} Graph;

typedef struct Node {
    char* token;
} Node;

// Function prototypes
Graph* create_graph(int capacity);
void destroy_graph(Graph* graph);
Node* create_node(const char* token, int value);
void add_node(Graph* graph, Node* node);

#endif // UNIFIED_VOICE_H
